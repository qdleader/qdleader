import React from 'react'

function dashboard() {
    return (
        <div>
            <h1>后台dashboard页</h1>
        </div>
    )
}

export default dashboard
