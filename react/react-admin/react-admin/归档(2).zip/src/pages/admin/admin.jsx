import React ,{Component}from 'react';

//登录的路由组件

export default class Admin extends Component {
    render () {
        return (
            <div className="login">
                Admin
            </div>
        )
    }
}