import React from 'react'

function List() {
    return (
        <div>
            <h2>列表页面</h2>
        </div>
    )
}

export default List
