import React from 'react'
import {Button,message} from 'antd'
function Edit() {
    
    return (
        <div>
            <h1>编辑页面</h1>
        </div>
    )
}

export default Edit
